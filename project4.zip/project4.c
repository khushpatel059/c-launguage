#include <stdio.h>
main(){

    printf("\nQ1\n\n");


    for (int i = 41; i<= 45; i++)
    {
         
        for (int j = 41; j <= i; j++)
        {
            printf("%d ",j);
        }

        printf("\n");

    }

    printf("\nQ2\n\n");


    int a=11;

   for (int i = 1; i <= 4; i++)
   {
    for (int j = 1; j <=i; j++)
    {
        printf("%d ",a);
        a++;
    }
    printf("\n");
   }
    
     printf("\nQ3\n\n");


    for (int i = 5; i >= 1; i--)
    {
        for (int k = i; k > 1; k--)
        {
            printf("  ");
        }
        
        for (int j = i; j <= 5; j++){
            printf("%d ",j);
        }
        printf("\n");
    }

    printf("\nQ4\n\n");

    for (int i = 1; i <=5; i++)
    {
        for (int k = 1; k <= 6-i; k++)
        {
            printf("  ");
        }
        
        for (int j = 1; j <= i; j++){
            printf("%d ",j % 2);
        }
        printf("\n");
    }

    printf("\nQ5\n\n");

    for (int i = 5; i >= 1; i--){
        for (int j = i; j >= 1; j--){
            printf("  ",j);
        }
        for (int j = i; j <= 5; j++){
            printf("%d ",j);
        }
        for (int j = 4; j >= i; j--){
            printf("%d ",j);
        }
        printf("\n");
    }

    printf("\nQ6\n\n");

    for (int i = 1; i <= 5; i++){
        for (int j = 1; j <= i; j++){
            printf("%d ",j);
        }
        for (int j = 4; j >= i; j--){
            printf("  ",j);
        }
        for (int j = 4; j >= i; j--){
            printf("  ",j);
        }
        for (int j = i; j >= 1; j--){
            printf("%d ",j);
        }
        printf("\n");
    }
    printf("\nQ7\n\n");

     int i,j;

  for (int i = 1; i <=7; i++)
  {
    for (int j = 1; j <=5; j++)
    {
      if (j==1 || (i==1 && j<5) || (i==4 && j<5) || (j==5&& i>1&&i<4))
      {
        printf("* ",j);
      }
      else{
        printf("  ");
      }
    }
     printf("\n");
  }
  
}